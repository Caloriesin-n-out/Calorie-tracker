// Additive shared-account connector. No credential values belong in this source.
const SHARED_EMAIL = 'anaymatti@gmail.com';
const SHARED_SERVICE = 'shared-tasks';
const SHARED_SCOPES = ['openid', 'email', 'https://www.googleapis.com/auth/tasks', 'https://www.googleapis.com/auth/calendar.readonly'];
const SHARED_CONFIG = 'sharedTasks:config';
const SHARED_IDENTITY = 'sharedTasks:identity';
function authService(value) {
  if (value === null || value === undefined || value === '' || value === 'health') return 'health';
  if (value === 'calendar' || value === SHARED_SERVICE) return value;
  throw fail('Unknown connection service.', 400, true);
}
async function verifySharedGrant(env, tok) {
  const granted = new Set(String(tok.scope || '').split(/\s+/));
  for (const s of SHARED_SCOPES.filter(s => s.startsWith('https://'))) {
    if (!granted.has(s)) throw fail('Shared Tasks and calendar permissions were not both approved. Existing connections were kept.', 403, true);
  }
  const r = await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tok.access_token}` } });
  const who = await r.json().catch(() => ({}));
  if (!r.ok || who.email_verified !== true || String(who.email || '').toLowerCase() !== SHARED_EMAIL || !who.sub) {
    throw fail('Choose the shared anaymatti@gmail.com account. No existing connection was replaced.', 403, true);
  }
  const old = await env.TOKENS.get(SHARED_IDENTITY, 'json');
  if (old?.sub && old.sub !== who.sub) throw fail('Shared account identity changed. Existing connections were kept.', 403, true);
  return { sub: who.sub, email: SHARED_EMAIL };
}
async function sharedConfig(env) { return (await env.TOKENS.get(SHARED_CONFIG, 'json')) || null; }
async function sharedStatus(env) {
  const identity = await env.TOKENS.get(SHARED_IDENTITY, 'json');
  const config = await sharedConfig(env);
  return { connected: !!(await env.TOKENS.get('refreshToken:shared-tasks')), account: identity?.email || null, list: config ? { id: config.listId, title: config.listTitle } : null };
}
async function sharedGoogle(env, service, path, init = {}) {
  const token = await accessToken(env, SHARED_SERVICE);
  const origin = service === 'tasks' ? 'https://tasks.googleapis.com/tasks/v1/' : 'https://www.googleapis.com/calendar/v3/';
  const r = await fetch(origin + path, { ...init, headers: { Authorization: `Bearer ${token}`, ...(init.body ? { 'Content-Type': 'application/json' } : {}), ...(init.headers || {}) } });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401) await env.TOKENS.delete('accessToken:shared-tasks');
    const raw = String(data.error?.message || '');
    if (r.status === 403 && /not been used|disabled|accessNotConfigured/i.test(raw)) throw fail(`The Google ${service === 'tasks' ? 'Tasks' : 'Calendar'} API needs enabling in the app's Google Cloud project.`, 403, true);
    if (r.status === 401) throw fail('Shared Google access needs reconnecting. Personal connections were kept.', 401, true);
    if (r.status === 403) throw fail('Shared Google permission was refused. Check the connection and selected list.', 403, true);
    if (r.status === 404) throw fail('The shared list or task no longer exists, or access was removed. Refresh the shared list.', 404, true);
    if (r.status === 412) throw fail('This task changed on another device. Refresh before changing it again.', 409, true);
    throw fail(`Shared Google request failed (${r.status}). Try refreshing.`, 502, true);
  }
  return data;
}
async function sharedPages(env, service, path, params = {}) {
  const out = []; let pageToken = null; const seen = new Set();
  do {
    const q = new URLSearchParams({ ...params, ...(pageToken ? { pageToken } : {}) });
    const page = await sharedGoogle(env, service, `${path}?${q}`);
    out.push(...(page.items || []));
    pageToken = page.nextPageToken || null;
    if (pageToken && (seen.has(pageToken) || seen.size >= 1000)) throw fail('The shared list could not be loaded completely. Try refreshing.', 502, true);
    if (pageToken) seen.add(pageToken);
  } while (pageToken);
  return out;
}
async function sharedLists(env) {
  const items = await sharedPages(env, 'tasks', 'users/@me/lists', { maxResults: '100' });
  return { account: SHARED_EMAIL, lists: items.map(x => ({ id: x.id, title: x.title || '(untitled list)' })) };
}
async function sharedSelect(env, body) {
  const listId = String(body.listId || '');
  if (!listId || listId.length > 1000) throw fail('Choose an existing shared task list.', 400, true);
  const available = await sharedLists(env);
  const selected = available.lists.find(x => x.id === listId);
  if (!selected) throw fail('That list is not available in the shared account.', 403, true);
  const identity = await env.TOKENS.get(SHARED_IDENTITY, 'json');
  if (!identity?.sub || identity.email !== SHARED_EMAIL) throw fail('Reconnect the shared account first.', 409, true);
  const config = { listId: selected.id, listTitle: selected.title, accountSub: identity.sub };
  await env.TOKENS.put(SHARED_CONFIG, JSON.stringify(config));
  return { account: SHARED_EMAIL, list: selected };
}
async function requireSharedList(env) {
  const identity = await env.TOKENS.get(SHARED_IDENTITY, 'json');
  const config = await sharedConfig(env);
  if (!config || !identity?.sub || config.accountSub !== identity.sub) throw fail('Choose your shared Google task list in Settings first.', 409, true);
  return config;
}
function sharedCivilDay(value) {
  return value && /^\d{4}-\d{2}-\d{2}/.test(value) ? value.slice(0, 10) : null;
}
function validSharedDay(s) {
  return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s)) && new Date(s).toISOString().slice(0, 10) === s;
}
function mapGoogleTask(task, listId) {
  const completed = task.status === 'completed';
  // Google Tasks API due is a civil date, never a scheduled time.
  const done = completed && task.completed ? new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Madrid', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(task.completed)) : null;
  return { id: `gtask:${encodeURIComponent(listId)}:${encodeURIComponent(task.id)}`, upstreamId: task.id, listId, source: 'shared-google', title: task.title || '(untitled)', status: completed ? 'Done' : 'Not started', due: sharedCivilDay(task.due), done, completedAt: task.completed || null, types: [], tags: [], waiting: false, next: '', notes: task.notes || '', url: task.webViewLink || null, people: [], crm: false, parent: task.parent || null, position: task.position || '', etag: task.etag || null, updated: task.updated || null };
}
async function sharedTasks(env, url) {
  const date = url.searchParams.get('date');
  if (!validSharedDay(date)) throw fail('Bad date.', 400, true);
  const config = await requireSharedList(env);
  const items = await sharedPages(env, 'tasks', `lists/${encodeURIComponent(config.listId)}/tasks`, { maxResults: '100', showCompleted: 'true', showHidden: 'true', showDeleted: 'true' });
  const rows = items.filter(x => !x.deleted).map(x => mapGoogleTask(x, config.listId));
  return { account: SHARED_EMAIL, list: { id: config.listId, title: config.listTitle }, open: rows.filter(x => x.status !== 'Done'), doneOn: rows.filter(x => x.status === 'Done' && x.done === date), at: Date.now() };
}
async function sharedAction(env, action, body) {
  const config = await requireSharedList(env);
  const base = `lists/${encodeURIComponent(config.listId)}/tasks`;
  if (action === 'add') {
    const title = String(body.title || '').trim();
    if (!title || title.length > 200) throw fail('Give the task a title (up to 200 characters).', 400, true);
    if (body.due && !validSharedDay(body.due)) throw fail('Bad due date.', 400, true);
    // No CRM/mail notes or person/type metadata are copied into the shared account.
    const created = await sharedGoogle(env, 'tasks', base, { method: 'POST', body: JSON.stringify({ title, ...(body.due ? { due: `${body.due}T00:00:00.000Z` } : {}) }) });
    return { task: mapGoogleTask(created, config.listId) };
  }
  if (!['done', 'reopen'].includes(action)) throw fail('Not found.', 404, true);
  const taskId = String(body.upstreamId || '');
  if (!taskId || taskId.length > 1000 || body.listId !== config.listId) throw fail('Refresh the selected shared task list first.', 400, true);
  if (!body.etag || typeof body.etag !== 'string' || /[\r\n]/.test(body.etag)) throw fail('Refresh this task before changing it.', 409, true);
  const path = `${base}/${encodeURIComponent(taskId)}`;
  const current = await sharedGoogle(env, 'tasks', path);
  if (current.deleted || current.etag !== body.etag) throw fail('This task changed on another device. Refresh before changing it again.', 409, true);
  const patch = action === 'done' ? { status: 'completed' } : { status: 'needsAction', completed: null };
  const updated = await sharedGoogle(env, 'tasks', path, { method: 'PATCH', headers: { 'If-Match': current.etag }, body: JSON.stringify(patch) });
  return { task: mapGoogleTask(updated, config.listId) };
}
async function sharedCalendar(env, url) {
  const from = Date.parse(url.searchParams.get('from') || ''), to = Date.parse(url.searchParams.get('to') || '');
  if (!Number.isFinite(from) || !Number.isFinite(to) || to <= from || to - from > 8 * 86400e3) throw fail('Bad time range.', 400, true);
  const cal = await sharedGoogle(env, 'calendar', 'calendars/primary');
  const id = cal.id;
  if (!id) throw fail('The shared calendar could not be identified.', 502, true);
  const name = cal.summary || SHARED_EMAIL;
  const items = await sharedPages(env, 'calendar', `calendars/${encodeURIComponent(id)}/events`, { timeMin: new Date(from).toISOString(), timeMax: new Date(to).toISOString(), singleEvents: 'true', orderBy: 'startTime', maxResults: '250' });
  const events = items.map(e => { const x = mapEvent(e, name); return x ? { ...x, calendarId: id, source: 'shared-google', readOnly: true } : null; }).filter(e => e && e.start);
  return { events, errors: [], calendars: [name], calendarList: [{ id, summary: name, primary: true, accessRole: 'reader', source: 'shared-google', readOnly: true }], at: Date.now() };
}
