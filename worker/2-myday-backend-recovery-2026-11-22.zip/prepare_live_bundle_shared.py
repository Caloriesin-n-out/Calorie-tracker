#!/usr/bin/env python3
"""Offline additive patch against the recovered 2026-11-22 live module bundle.
No credentials, commits, deployments or network calls. Fails closed on another baseline.
"""
from pathlib import Path
import sys,hashlib,json
EXPECTED='2ce52ef1216c4a64a6457a9603b3431de91ea46574327f412b1820f166570527'
source=Path(sys.argv[1]).read_text()
if hashlib.sha256(source.encode()).hexdigest()!=EXPECTED:raise SystemExit('Baseline hash changed. Recover/review current deployed source before rebasing.')
s=source;changes=[]
def rep(old,new):
 global s
 if s.count(old)!=1:raise SystemExit(f'Anchor mismatch ({s.count(old)}): '+old[:100])
 s=s.replace(old,new);changes.append({'before':old,'after':new})
rep('var keys = /* @__PURE__ */ __name((service) => service === "calendar" ?', 'var keys = /* @__PURE__ */ __name((service) => service === "shared-tasks" ? { refresh: "refreshToken:shared-tasks", access: "accessToken:shared-tasks", scopes: "grantedScopes:shared-tasks", label: "Shared Google Tasks and calendar" } : service === "calendar" ?')
rep('var scopes = /* @__PURE__ */ __name((env, service) => service === "calendar" ? CALENDAR_SCOPES.join(" ") : env.SCOPES || DEFAULT_SCOPES.join(" "), "scopes");','var scopes = /* @__PURE__ */ __name((env, service) => service === "shared-tasks" ? SHARED_SCOPES.join(" ") : service === "calendar" ? CALENDAR_SCOPES.join(" ") : env.SCOPES || DEFAULT_SCOPES.join(" "), "scopes");')
rep('if (url.pathname === "/auth/start") return authStart(request, env, url);', 'if (url.pathname === "/auth/start") return await authStart(request, env, url);')
rep('if (url.pathname === "/auth/callback") return authCallback(env, url);', 'if (url.pathname === "/auth/callback") return await authCallback(env, url);')
rep('const service2 = form.get("service") === "calendar" ? "calendar" : "health";','const service2 = authService(form.get("service"));')
rep('const service = url.searchParams.get("service") === "calendar" ? "calendar" : "health";','const service = authService(url.searchParams.get("service"));')
rep('const service = stored === "calendar" ? "calendar" : "health", K = keys(service);','const service = authService(stored), K = keys(service);')
rep('      access_type: "offline",','      access_type: "offline",\n      ...(service2 === SHARED_SERVICE ? { login_hint: SHARED_EMAIL, include_granted_scopes: "false" } : {}),')
rep('  await env.TOKENS.put(K.refresh, tok.refresh_token);','  const sharedIdentity = service === SHARED_SERVICE ? await verifySharedGrant(env, tok) : null;\n  await env.TOKENS.put(K.refresh, tok.refresh_token);\n  if (sharedIdentity) await env.TOKENS.put(SHARED_IDENTITY, JSON.stringify(sharedIdentity));')
start=s.index('async function accessToken(');end=s.index('__name(accessToken, "accessToken");',start)
before=s[start:end];after=before.replace('service === "calendar"','service !== "health"')
rep(before,after)
routes='''
        if (url.pathname === "/api/shared-tasks/status") {
          if (request.method !== "GET") return json({ error: "Use GET." }, 405, request, env);
          return json(await sharedStatus(env), 200, request, env);
        }
        if (url.pathname === "/api/shared-tasks/lists") {
          if (request.method !== "GET") return json({ error: "Use GET." }, 405, request, env);
          return json(await sharedLists(env), 200, request, env);
        }
        if (url.pathname === "/api/shared-tasks") {
          if (request.method !== "GET") return json({ error: "Use GET." }, 405, request, env);
          return json(await sharedTasks(env, url), 200, request, env);
        }
        if (url.pathname === "/api/shared-calendar") {
          if (request.method !== "GET") return json({ error: "Use GET." }, 405, request, env);
          return json(await sharedCalendar(env, url), 200, request, env);
        }
        if (url.pathname.startsWith("/api/shared-tasks/")) {
          if (request.method !== "POST") return json({ error: "Use POST." }, 405, request, env);
          const action = url.pathname.slice("/api/shared-tasks/".length);
          if (!["select", "add", "done", "reopen"].includes(action)) return json({ error: "Not found." }, 404, request, env);
          const body = await request.json().catch(() => ({}));
          return json(action === "select" ? await sharedSelect(env, body) : await sharedAction(env, action, body), 200, request, env);
        }
'''
anchor='        if (url.pathname === "/api/status") return json(await status(env), 200, request, env);'
rep(anchor,anchor+routes)
ext=Path(__file__).with_name('shared-tasks-extension.js').read_text()
s+='\n/* ---------------- Shared Google Tasks and read-only calendar ---------------- */\n'+ext
Path(sys.argv[2]).write_text(s)
# Reverse every explicit edit and drop the additive extension: exact round-trip proves
# all unrelated code including importers, DOs and restricted wrappers is untouched.
back=s[:s.index('\n/* ---------------- Shared Google Tasks and read-only calendar ---------------- */')]
for c in reversed(changes):
 if back.count(c['after'])!=1:raise SystemExit('Non-reversible patch entry')
 back=back.replace(c['after'],c['before'])
assert back==source,'Unrelated baseline changed'
manifest={'baseline_sha256':EXPECTED,'output_sha256':hashlib.sha256(s.encode()).hexdigest(),'changed_regions':len(changes),'unrelated_code_roundtrip_exact':True,'deployment_performed':False}
Path(sys.argv[2]+'.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
